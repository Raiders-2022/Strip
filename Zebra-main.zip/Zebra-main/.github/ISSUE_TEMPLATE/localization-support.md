---
name: Localization support
about: Add support for a new language in Zebra
title: ''
labels: localization
assignees: ''

---

**What language are you adding?**


**Please paste a link to the translated .strings file you have created. If you have not created a .strings file already, please see [the README](https://github.com/wstyres/Zebra#translations) for more info**


**Are you a member of our discord? If so, what is your username so we can give you a special role to be notified of future translation updates**


**How would you like to be credited? (Name, Twitter Link, Website, etc.)**
