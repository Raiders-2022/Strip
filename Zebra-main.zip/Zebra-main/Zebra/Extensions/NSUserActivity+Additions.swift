//
//  NSUserActivity+Additions.swift
//  Zebra
//
//  Created by Adam Demasi on 26/2/2022.
//  Copyright © 2022 Zebra Team. All rights reserved.
//

import Foundation

struct UserActivityUserInfoKey {
	static let url = "url"
}
