//
//  ZBChangelogViewController.h
//  Zebra
//
//  Created by midnightchips on 6/30/19.
//  Copyright © 2019 Wilson Styres. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZBChangelogViewController : UITableViewController
@property NSMutableArray *releases;
@end
