//
//  ZBFilterDelegate.h
//  Zebra
//
//  Created by Wilson Styres on 11/15/20.
//  Copyright © 2020 Wilson Styres. All rights reserved.
//

@protocol ZBFilterDelegate
- (void)applyFilter:(id)filter;
@end
