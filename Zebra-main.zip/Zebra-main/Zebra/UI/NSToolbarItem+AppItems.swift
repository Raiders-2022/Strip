//
//  NSToolbarItem+AppItems.swift
//  Zebra
//
//  Created by Adam Demasi on 12/2/2022.
//  Copyright © 2022 Zebra Team. All rights reserved.
//

import UIKit

#if targetEnvironment(macCatalyst)
extension NSToolbarItem.Identifier {
	static let back = NSToolbarItem.Identifier(rawValue: "back")
}
#endif
