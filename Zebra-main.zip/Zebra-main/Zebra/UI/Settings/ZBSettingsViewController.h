//
//  MainSettingsTableViewController.h
//  Zebra
//
//  Created by midnightchips on 6/22/19.
//  Copyright © 2019 Wilson Styres. All rights reserved.
//

#import "ZBPreferencesViewController.h"

@interface ZBSettingsViewController : ZBPreferencesViewController

@end
