//
//  ZBSourceListViewController.h
//  Zebra
//
//  Created by Wilson Styres on 1/1/21.
//  Copyright © 2021 Wilson Styres. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ZBSourceListViewController : UITableViewController
- (void)addButton:(id)sender;
- (void)refreshButton:(id)sender;
@end

NS_ASSUME_NONNULL_END
