//
//  ZBChangelogTableViewCell.m
//  Zebra
//
//  Created by Wilson Styres on 5/17/20.
//  Copyright © 2020 Wilson Styres. All rights reserved.
//

#import "ZBChangelogTableViewCell.h"

@implementation ZBChangelogTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    
    [self setSelectionStyle:UITableViewCellSelectionStyleNone];
}

@end
